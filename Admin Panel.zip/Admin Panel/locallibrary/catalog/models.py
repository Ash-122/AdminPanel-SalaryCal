from django.db import models
from datetime import datetime
from datetime import date
from django.db.models.fields import DateField
from django.db.models.functions import Cast
from datetime import timedelta
from django.contrib.auth.models import User


from django.contrib.auth.models import AbstractUser
from django.db import models

   
from datetime import datetime
        
from datetime import timedelta
from django.db import models
from django.utils import timezone as tz

class employee1(models.Model):
    
    Date = models.CharField(max_length=30, help_text="date")
    Name = models.CharField(max_length=30, help_text="Name")
    Number= models.CharField(max_length=30, help_text="Number")

    Time_IN = models.CharField(max_length=30,default='00:00:00 AM' , help_text="Time_In")
    Time_OUT = models.CharField(max_length=20,default='00:00:00 AM', help_text="Time_out")
    base_salary = models.IntegerField(default=0)
    total_salary = models.IntegerField( default=0)



    def calculate_salary(self):
        #worked_hours = (self.time_out - self.time_in).total_seconds() / 60 / 60
        from datetime import datetime
        FMT = '%H:%M:%S %p'
        x= datetime.strptime(self.Time_OUT,FMT)
        a= datetime.strptime(self.Time_IN,FMT)


        worked_hours = (x - a).total_seconds() / 60 / 60
        overtime_hours = 0

        same_day_8pm="20:00:00 PM"
        same_day_8pm = datetime.strptime(same_day_8pm,FMT)
       # same_day_8pm= same_day_8pm.replace(hour=20, minute=0, second=0)
       
        if x > same_day_8pm:
            overtime_hours = (x - same_day_8pm).total_seconds() / 60 / 60

        salary_1 = worked_hours * self.base_salary
        salary_2 = overtime_hours * self.base_salary * 0.2
        total_salary = salary_1 + salary_2

        return total_salary

    def save(self,*args,**kwargs):
        self.total_salary = (self.calculate_salary())
        # are you really sure that you want to save a string ???
        super().save(*args, **kwargs)

    def __str__(self):
        return self.Name

class employee(models.Model):
    
    emp_id = models.AutoField(primary_key=True, help_text="Enter a Emp Id")

    name = models.CharField(max_length=200,default='0', help_text="Enter a Name")

    email_id = models.EmailField(max_length=70,blank=True)

    contact_no =  models.IntegerField(default='0',help_text="10 Digits only")

    SKILLS = (
        ('HTML', 'HTML'),
        ('XML', 'XML'),
        ('Javascript', 'Javascript'),
        ('VBScript', 'VBScript'),
        ('PHP', 'PHP'),
        ('JAVA', 'JAVA'),
        ('C', 'C'),
        ('C++', 'C++'),
        ('C#', 'C#'),
        ('Visual Basic', 'Visual Basic'),
        ('Objective C', 'Objective C'),
        ('RUBY', 'RUBY'),
        ('PYTHON', 'PYTHON'),
        ('PEARL', 'PEARL'),
        ('SQL', 'SQL')
    )
    
    skill = models.CharField(max_length=20, choices=SKILLS)

    experience = models.IntegerField(help_text="Year.Months")
    
    def __str__(self):
       
        return self.name


#---------------------------------------------------------------------------------------------------------------------


from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.contrib.auth.models import Group
class UserProfile(models.Model):  
    user = models.OneToOneField(User,null = True,on_delete=models.CASCADE)
    #use_in_migrations = True
    #user.is_staff=True 
    #user.groups.add(name='CUSTOMER') 
    #is_staff = models.BooleanField(default=True)
    
    def __str__(self):  
          return "%s's profile" % self.user  

def create_user_profile(sender, instance, created, **kwargs):  
    if created:  
       profile, created = UserProfile.objects.get_or_create(user=instance)  
        
post_save.connect(create_user_profile, sender=User) 

    #--------------------------------------------------------------------------------------------------------------------

class project(models.Model):

    #proj_id = models.AutoField(primary_key=True,default='0')

    #user_cust = models.ForeignKey('customer',on_delete=models.CASCADE)
    user_emp = models.ForeignKey('employee',on_delete=models.CASCADE)
    project_topic = models.CharField(max_length=20,default='0', help_text="Enter a Project Name")

    description = models.CharField(max_length=200,default='0', help_text="Enter a full Description of your Project")

    expected_delivery = models.DateField(("Expected Delivery"), default=date.today)

    LANGUAGE = (
        ('ANY', 'ANY'),
        ('H', 'HTML'),
        ('X', 'XML'),
        ('JS', 'Javascript'),
        ('VBS', 'VBScript'),
        ('PHP', 'PHP'),
        ('J', 'JAVA'),
        ('C', 'C'),
        ('C++', 'C++'),
        ('C#', 'C#'),
        ('VB', 'Visual Basic'),
        ('OC', 'Objective C'),
        ('R', 'RUBY'),
        ('PY', 'PYTHON'),
        ('PER', 'PEARL'),
        ('SQL', 'SQL')
    )
    language = models.CharField(max_length=3, default='ANY', choices=LANGUAGE)


    PROJ_STATUS = (
        ('PENDING','PENDING'),
        ('REQUIREMENT', 'REQUIREMENT'),
        ('DESIGN', 'DESIGN'),
        ('ANALYSIS', 'ANALYSIS'),
        ('CODING', 'CODING'),
        ('TESTING', 'TESTING'),
        ('OPERATION', 'OPERATION')
    )
    
    proj_status = models.CharField(max_length=20, default='PENDING', choices=PROJ_STATUS)

    #entry_list1 = list(UserProfile.objects.get(emp_status='A'))

    def __str__(self):
       
        return self.project_topic
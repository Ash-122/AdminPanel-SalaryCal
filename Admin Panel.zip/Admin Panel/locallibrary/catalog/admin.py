from django.contrib import admin
# Register your models here.
from .models import employee,project,UserProfile,employee1
from django.db import models
admin.site.register(UserProfile)
admin.site.register(employee1)
#admin.site.register(empstat)
#admin.site.register(Quiz)

admin.site.register(employee)

#admin.site.register(customer)

admin.site.register(project)
admin.site.site_header="D'Tech Solutions"

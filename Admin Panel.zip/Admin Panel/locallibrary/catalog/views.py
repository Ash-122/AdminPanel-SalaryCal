from django.shortcuts import render
from .models import employee,project,UserProfile,employee
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect


def index(request):
    """
    View function for home page of site.
    """
    # Generate counts of some of the main objects
    num_emp=UserProfile.objects.all().count()

    return render(
        request,
        'index.html',
    )

def after_cust_login(request):
    """
    View function for home page of site.
    """
    num_projects=project.objects.all().count()
    num_employees=UserProfile.objects.all().count()

    # Generate counts of some of the main objects
    proj_stat = project.objects.all()[:50]
    profile=UserProfile.objects.all()[:50]

    return render(
        request,
        'after_cust_login.html',
        context={'num_projects':num_projects,'proj_stat':proj_stat,'profile':profile,'num_employees':num_employees,},
    )


def about_us(request):

    return render(
        request,
        'about_us.html',
    )

def contact_us(request):

    return render(
        request,
        'contact_us.html',
    )


def password_reset(request):
    """
    View function for home page of site.
    """
    
    
    # Render the HTML template index.html with the data in the context variable
    return render(
        request,
        'password_reset.html')


def password_reset_done(request):
    """
    View function for home page of site.
    """
    
    
    # Render the HTML template index.html with the data in the context variable
    return render(
        request,
        'password_reset_done.html')

def password_reset_confirm(request):
    """
    View function for home page of site.
    """
    
    
    # Render the HTML template index.html with the data in the context variable
    return render(
        request,
        'password_reset_confirm.html')

def password_reset_complete(request):
    """
    View function for home page of site.
    """
    
    
    # Render the HTML template index.html with the data in the context variable
    return render(
        request,
        'password_reset_complete.html')


@login_required
def home(request):
    num_projects=project.objects.all().count()
    num_employees=employee.objects.all().count()

    # Generate counts of some of the main objects
    proj_stat = project.objects.all()[:50]
    profile1=UserProfile.objects.all()[:50]
    profile=employee.objects.all()[:50]
    profilez=project.objects.all()[:50]

    return render(
        request,
        'home.html',
        context={'num_projects':num_projects,'proj_stat':proj_stat,'profile':profile,'num_employees':num_employees,},
    )
from django.contrib.auth.models import Group
def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            group = Group.objects.get(name='CUSTOMER')
            user.groups.add(group)
    
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})

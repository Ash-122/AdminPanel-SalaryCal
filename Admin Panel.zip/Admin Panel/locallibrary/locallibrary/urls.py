from django.contrib import admin
from django.urls import path

urlpatterns = [
    path('admin/', admin.site.urls),
]


from django.conf.urls import url, include
from django.contrib.auth import views as auth_views

from catalog import views as core_views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns 


urlpatterns += [
    path('', core_views.index, name='index'),
    path('r^about_us',core_views.about_us,name='about_us'),
    path('r^contact_us',core_views.contact_us,name='contact_us'),
    path('r^after_cust_login',core_views.after_cust_login,name='after_cust_login'),
    
]


urlpatterns += [
    url(r'^home/$', core_views.home, name='home'),
    url(r'^login/$', auth_views.login, {'template_name': 'login.html'}, name='login'),
    url(r'^logout/$', auth_views.logout, {'next_page': 'login'}, name='logout'),
    url(r'^signup/$', core_views.signup, name='signup'),
]

from django.contrib.auth import views as auth_views

urlpatterns += [
    
    url(r'^password_reset/$', auth_views.password_reset, name='password_reset'),
    url(r'^password_reset/done/$', auth_views.password_reset_done, name='password_reset_done'),
    url(r'^reset/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$',
        auth_views.password_reset_confirm, name='password_reset_confirm'),
    url(r'^reset/done/$', auth_views.password_reset_complete, name='password_reset_complete'),
]
urlpatterns += staticfiles_urlpatterns()
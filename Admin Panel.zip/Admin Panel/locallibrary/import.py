#!/usr/bin/env python
import os
import sys
import csv
from datetime import datetime
#import datetime

project_dir='catalog'
sys.path.append(project_dir)

#import settings
#from django.conf import settings
os.environ['DJANGO_SETTINGS_MODULE']='locallibrary.settings'
import django

django.setup()
#import models
from catalog.models import employee1
data=csv.reader(open('locallibrary/WorkNames.csv'),delimiter=',')

from datetime import datetime

lines=list(data)

r=7
c=7

for i in range(r):
    for j in range(i+1,c):
        
        if lines[i][2] == lines[j][2]:
            lines[i][4]=lines[j][4]
            lines[j][2]=""
            lines[j][1]=""
            lines[j][4]=""
            lines[j][0]=""

r=7
c=5

writer = csv.writer(open('locallibrary/output.csv', 'w'))
for r in lines:
    writer.writerow(r)

with open('locallibrary/output.csv') as csvfile:
    fieldnames = ['Date', 'Name','Number','Time IN','Time OUT']
    reader = csv.DictReader(csvfile)
    for row in reader:
        if row['Date']=='':
            break
        else:
            Employee1=employee1()
            Employee1.Date=row['Date']
            Employee1.Name=row['Name']
            Employee1.Number=row['Number']
            Employee1.Time_IN=row['Time IN']
            Employee1.Time_OUT=row['Time OUT']
            Employee1.save()
